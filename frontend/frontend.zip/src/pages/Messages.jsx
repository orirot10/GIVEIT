import React from 'react';
import Messages from '../components/Messages';
import { useAuthContext } from '../context/AuthContext'; // adjust the path as needed

const MessagesPage = () => {
  const { user } = useAuthContext(); // Access user from context
  console.log(user); // 👈 Put it here!

  if (!user) {
    return <p>Loading...</p>; // Or redirect to login if user is not authenticated
  }

  return (
    <div style={{ padding: '2rem' }}> {/* Add padding like other pages */}
      <h2 className="text-2xl font-bold text-center mb-4">Chat</h2> {/* Added title with common styling */}
      <Messages userId={user.user.id} />
    </div>
  );
};

export default MessagesPage;
