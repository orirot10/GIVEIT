export const rentalCategories = [
    'Tools',
    'Electronics',
    'Vehicles',
    'Sports',
    'Furniture',
    'Clothes',
    'Other',
];

export const serviceCategories = [
    'Repair',
    'Cleaning',
    'Tutoring',
    'Moving',
    'Pet Care',
    'Beauty',
    'Other',
];