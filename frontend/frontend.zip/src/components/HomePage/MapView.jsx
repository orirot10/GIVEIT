import React, { useState, useEffect } from "react";
import { GoogleMap, InfoWindow, OverlayView } from "@react-google-maps/api";

const containerStyle = {
  width: "100%",
  height: "100%",
};

// Default center if user location isn't available
const defaultCenter = {
  lat: 32.0853,
  lng: 34.7818,
};

const IMAGE_BASE_URL = "http://localhost:5000";

const MapView = ({ locations }) => {
  const [selected, setSelected] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [mapRef, setMapRef] = useState(null);

  // 1km zoom level is approximately zoom level 15
  const zoomLevel = 15;

  // Get user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userPos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setUserLocation(userPos);
          setMapCenter(userPos);
        },
        (error) => {
          console.error("Error getting user location:", error);
        }
      );
    } else {
      console.log("Geolocation is not supported by this browser.");
    }
  }, []);

  // Store map reference on load
  const onMapLoad = (map) => {
    setMapRef(map);
  };

  // Custom marker component using OverlayView
  const CircleMarker = ({ item }) => {
    return (
      <OverlayView
        position={{ lat: item.lat, lng: item.lng }}
        mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
      >
        <div className="relative">
          {/* Main circle with product name */}
          <div
            className="flex items-center justify-center rounded-full bg-blue-500 text-white font-medium text-xs cursor-pointer shadow-md hover:bg-blue-600 transition-colors"
            style={{ width: "60px", height: "60px", padding: "4px" }}
            onClick={() => setSelected(item)}
          >
            <span className="text-center truncate">{item.title}</span>
          </div>
          
          {/* Price ellipsoid - positioned at bottom center, partially outside circle */}
          <div 
            className="absolute  transform  bottom-0  flex items-center justify-center bg-orange-500 text-white text-xs font-bold rounded-full px-2 shadow-md border border-white z-10"
            style={{ minWidth: "36px", height: "20px" }}
          >
            {item.price}₪
          </div>
        </div>
      </OverlayView>
    );
  };

  // User location marker
  const UserLocationMarker = () => {
    if (!userLocation) return null;

    return (
      <OverlayView
        position={userLocation}
        mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
      >
        <div
          className="rounded-full bg-green-500 border-2 border-white shadow-lg"
          style={{ width: "24px", height: "24px" }}
        >
          <div
            className="absolute animate-ping rounded-full bg-green-400 opacity-75"
            style={{ width: "24px", height: "24px" }}
          ></div>
        </div>
      </OverlayView>
    );
  };

  return (
    <GoogleMap 
      mapContainerStyle={containerStyle} 
      center={mapCenter} 
      zoom={zoomLevel}
      onLoad={onMapLoad}
    >
      {/* User location marker */}
      <UserLocationMarker />

      {/* Product markers */}
      {locations.map((item, index) => (
        <CircleMarker key={index} item={item} />
      ))}

      {selected && (
        <InfoWindow
          position={{ lat: selected.lat, lng: selected.lng }}
          onCloseClick={() => setSelected(null)}
        >
          <div className="max-w-xs">
            <img
              src={
                selected.images && selected.images.length
                  ? `${IMAGE_BASE_URL}${selected.images[0]}`
                  : "/default.jpg" // fallback image
              }
              alt={selected.title}
              className="w-full h-32 object-cover rounded mb-2"
            />
            <h3 className="text-lg font-semibold">{selected.title}</h3>
            <p className="text-sm text-gray-600">{selected.description}</p>
            <p className="text-sm">👤 {selected.firstName} {selected.lastName}</p>
            <p className="text-sm">📞 {selected.phone}</p>
            <p className="text-sm">💸 {selected.price}₪</p>
            <p className="text-sm">{selected.status}</p>
            <p className="text-sm">🏷️ {selected.category}</p>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
};

export default MapView;