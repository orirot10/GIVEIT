import React, { useState } from "react";
import ImagePopup from "./ListImagePopup.jsx"; // Import the new ImagePopup component
import '../../styles/HomePage/ListView.css';

const ListView = ({ items }) => {
const [selectedItem, setSelectedItem] = useState(null);

const handleClick = (item) => {
    setSelectedItem(item);
};

const handleClosePopup = () => {
    setSelectedItem(null);
};

return (
    <div className="list-container-wrapper">
    <div className="list-container">
        {items.map((item) => (
        <div
            key={item._id}
            className="rental-card"
            onClick={() => handleClick(item)}
        >
            {item.photo && (
            <img
                src={item.photo}
                alt={item.title}
                className="rental-image"
            />
            )}
            <h3 className="rental-title"> {item.title}</h3>
            <p className="rental-description">📝 {item.description}</p>
            <p className="rental-info">
            🏷️  {item.category}
            </p>
            <p className="rental-info">
            💸  {item.price}₪
            </p>
            <p className="rental-info">
                {item.status}
            </p>
            <p className="rental-info">
            📞  {item.firstName} {item.lastName} ({item.phone})
            </p>
        </div>
        ))}
    </div>

    {/* Display the pop-up if an item is selected */}
    {selectedItem && (
        <ImagePopup rental={selectedItem} onClose={handleClosePopup} />
    )}
    </div>
);
};

export default ListView;