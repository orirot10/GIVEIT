import React, { useEffect, useState } from "react";
import MapView from "./MapView";
import ListView from "./ListView";
import FilterButton from './FilterButton';
import ToggleViewButton from "./ToggleViewButton";
import { geocodeAddress } from "./geocode";
import SearchBar from "./SearchBar";
import '../../styles/HomePage/GenericMapPage.css';
import { handleSearch as searchItems } from "./searchHelpers";

const GenericMapPage = ({ title }) => {
const [allItems, setAllItems] = useState([]);
const [locations, setLocations] = useState([]);
const [view, setView] = useState("map");
const [viewMode, setViewMode] = useState("offers");
const [categoryType, setCategoryType] = useState("rentals");
const [searchQuery, setSearchQuery] = useState("");

// Function to get the correct API endpoint based on categoryType and viewMode
const getApiEndpoint = () => {
    // Base path depends on whether we want rentals or requests data
    const basePath = categoryType === 'rentals' ? '/api/rentals' : '/api/rental_requests';
    // Append the viewMode (offers/requests)
    const endpoint = `${basePath}/${viewMode}`;
    console.log("Constructed API Endpoint:", endpoint); // Debug log
    return endpoint;
};

useEffect(() => {
    const fetchAndMap = async () => {
    const endpoint = getApiEndpoint(); 
    console.log(`Fetching data from: ${endpoint}`); // Debug log
    try {
        const res = await fetch(endpoint);
        if (!res.ok) {
            // Log the response to see the error details if available
            const errorBody = await res.text(); 
            console.error(`Error fetching data: ${res.status} ${res.statusText}`, errorBody);
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const items = await res.json();
        console.log(`Fetched ${items.length} items from ${endpoint}`);

        setAllItems(items);
        const withCoords = await mapItemsToCoords(items);
        setLocations(withCoords);
    } catch (error) {
        console.error("Failed to fetch or map items:", error);
        setAllItems([]); // Clear items on error
        setLocations([]);
    }
};

    fetchAndMap();
    // Re-fetch when the category (rentals/requests) or the viewMode (offers/requests) changes
}, [categoryType, viewMode]); 

const mapItemsToCoords = async (items) => {
    const mapped = await Promise.all(
    items.map(async (item) => {
        const { street, city } = item;
        if (!item || !street || !city || street.length < 3 || city.length < 2) {
            console.warn("Skipping item due to missing/invalid address:", item?._id);
            return null;
        }
        try {
            const coords = await geocodeAddress(street, city);
            return coords
            ? {
                ...item,
                ...coords,
                id: item._id, // Ensure unique key if needed elsewhere
                }
            : null;
        } catch(error) {
            console.error("Geocoding error for address:", street, city, error);
            return null;
        }
    })
    );

    return mapped.filter(Boolean);
};

const handleSearch = () => {
    // Adjust search helper if needed, it should use the dynamic endpoint
    // Assuming the search helper takes the full endpoint URL
    // Remove unused endpoint variable
    // const endpoint = getApiEndpoint(); 
    // Assuming search endpoint is basePath/search?query=... NOT basePath/type/search?query=...
    // We might need dedicated search routes on the backend for requests (/api/rental_requests/search)
    // For now, let's assume search uses the base path + /search
    const searchEndpoint = `${categoryType === 'rentals' ? '/api/rentals' : '/api/rental_requests'}/search`;
    console.log(`Searching endpoint: ${searchEndpoint} for query: ${searchQuery}`);
    searchItems({ 
        apiUrl: searchEndpoint, // Use search-specific endpoint
        searchQuery, 
        setAllItems, 
        setLocations, 
        mapItemsToCoords
    });
};

const handleFilter = ({ categories, maxPrice }) => {
    // Similar to search, filter endpoint might need adjustment
    // Assuming filter endpoint is basePath/filter?params...
    const filterEndpoint = `${categoryType === 'rentals' ? '/api/rentals' : '/api/rental_requests'}/filter`;
    let url = `${filterEndpoint}?`;
    console.log(`Filtering endpoint: ${filterEndpoint} with:`, { categories, maxPrice });

    if (categories && categories.length > 0) {
    const encodedCategories = categories.map(encodeURIComponent).join(",");
    url += `category=${encodedCategories}&`;
    }

    if (maxPrice !== undefined && maxPrice !== null) {
        url += `maxPrice=${maxPrice}`;
    }
    // Ensure the URL doesn't end with ? or &
    if (url.endsWith('?') || url.endsWith('&')) {
        url = url.slice(0, -1);
    }

    fetch(url)
    .then((res) => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
    })
    .then(async (data) => {
        console.log("Filtered data received:", data);
        setAllItems(data);
        const withCoords = await mapItemsToCoords(data);
        setLocations(withCoords);
    })
    .catch(error => {
        console.error("Failed to fetch filtered items:", error);
        setAllItems([]);
        setLocations([]);
    });
};

return (
    <div className="p-3 flex flex-col items-center w-full">
    <h2 className="text-2xl font-bold text-center mb-2">{title || "Explore"}</h2>

    {/* Toggle between Rentals (offers) and Requests (rental_requests) Data Source */}
    <div className="view-mode-toggle mb-2">
        <button
            className={`toggle-btn ${categoryType === 'rentals' ? 'active' : ''}`}
            onClick={() => setCategoryType('rentals')}
        >
            Rentals
        </button>
        <button
            className={`toggle-btn ${categoryType === 'rental_requests' ? 'active' : ''}`}
            onClick={() => setCategoryType('rental_requests')}
        >
            Requests
        </button>
    </div>

    {/* Toggle between Offers and Requests View Mode (sub-type within category) */}
    <div className="view-mode-toggle mb-2">
        <button
            className={`toggle-btn ${viewMode === 'offers' ? 'active' : ''}`}
            onClick={() => setViewMode('offers')}
        >
            Offers
        </button>
        <button
            className={`toggle-btn ${viewMode === 'requests' ? 'active' : ''}`}
            onClick={() => setViewMode('requests')}
        >
            Requests
        </button>
    </div>

    <div className="search-filter-row">
        <div className="search-filter-container">
        <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSearch={handleSearch}
        />
        </div>
        <FilterButton
        onApplyFilters={handleFilter}
        // Pass the main category type for filter options
        categoryType={categoryType}
        />
    </div>

    <div className="map-wrapper w-full">
        <ToggleViewButton view={view} setView={setView} />
        {view === "map" ? (
        <MapView locations={locations} />
        ) : (
        <ListView items={allItems} />
        )}
    </div>
    </div>
);
};

export default GenericMapPage;