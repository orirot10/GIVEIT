const express = require('express');
const { uploadNewRental, getRentals, getUserRentals, editRental, deleteRental, searchRentals, filterRentals, getRentalsByType } = require('../controllers/rentalController.js');
const requireAuth = require('../middleware/authMiddleware.js');
const upload = require('../middleware/upload');

const router = express.Router();

// General GET routes first
router.get('/', getRentals);
router.get('/search', searchRentals);
router.get('/filter', filterRentals);
router.get('/user', requireAuth, getUserRentals);

// Dynamic Routes based on Type (offers/requests)
router.get('/:type', getRentalsByType);

// POST route (creation)
router.post('/', requireAuth, upload.array('images', 5), uploadNewRental);

// Routes acting on specific IDs (must be last for GET/PUT/DELETE with params)
router.put('/:id', requireAuth, editRental);
router.delete('/:id', requireAuth, deleteRental);

module.exports = router;