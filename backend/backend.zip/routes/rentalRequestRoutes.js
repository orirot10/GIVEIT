const express = require('express');
// Import only the necessary function from the controller
const { getRentalRequestsByType } = require('../controllers/rentalController.js');
// const requireAuth = require('../middleware/authMiddleware.js'); // Uncomment if auth is needed

const router = express.Router();

// Route to get rental requests based on type (offers/requests)
// Add requireAuth middleware here if needed
router.get('/:type', getRentalRequestsByType);

// Add other routes specific to rental requests if needed (e.g., POST, PUT, DELETE)

module.exports = router; 