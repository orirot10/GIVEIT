const Rental = require('../models/Rental.js');
const RentalRequest = require('../models/RentalRequest.js');

const uploadNewRental = async (req, res) => {
    const {
        title,
        description,
        category,
        price,
        phone,
        status,
        city,
        street
    } = req.body;

    if (!req.user) {
        return res.status(401).json({ error: 'Unauthorized. User data missing.' });
    }

    try {
        // Get uploaded file paths
        const imagePaths = req.files?.map(file => `/uploads/${file.filename}`) || [];

        const newRental = await Rental.create({
            firstName: req.user.firstName,
            lastName: req.user.lastName,
            email: req.user.email,
            title,
            description,
            category,
            price,
            images: imagePaths,
            phone,
            status,
            city,
            street
        });

        res.status(201).json(newRental);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get all rentals
const getRentals = async (req, res) => {
    try {
        const rentals = await Rental.find().sort({ createdAt: -1 });
        res.status(200).json(rentals);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch rentals' });
    }
};

// Get rentals for a specific user
const getUserRentals = async (req, res) => {
    const { email } = req.user; // set by auth middleware
    const page = parseInt(req.query.page);
    const limit = parseInt(req.query.limit); // optionally support a custom limit

    try {
        let query = Rental.find({ email }).sort({ createdAt: -1 });

        // Only apply pagination if `page` and `limit` are provided
        if (!isNaN(page) && !isNaN(limit)) {
            query = query.skip((page - 1) * limit).limit(limit);
        }

        const rentals = await query;
        res.status(200).json(rentals);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch user rentals' });
    }
};

// Edit a rental
const editRental = async (req, res) => {
    const { id } = req.params;
    const { title, description, category, price, images, phone } = req.body;

    try {
        const updated = await Rental.findByIdAndUpdate(
            id,
            { title, description, category, price, images, phone },
            { new: true }
        );

        if (!updated) return res.status(404).json({ error: 'Rental not found' });

        res.status(200).json(updated);
    } catch (err) {
        res.status(500).json({ error: 'Failed to update rental' });
    }
};

// Delete a rental
const deleteRental = async (req, res) => {
    const { id } = req.params;

    try {
        const deleted = await Rental.findByIdAndDelete(id);
        if (!deleted) return res.status(404).json({ error: 'Rental not found' });

        res.status(200).json({ message: 'Rental deleted' });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete rental' });
    }
};

const searchRentals = async (req, res) => {
    try {
        const { query } = req.query;

        if (!query || query.trim() === "") {
            return res.status(400).json({ message: "Query is required." });
        }

        // Split words for ordered search
        const words = query.trim().split(/\s+/);

        // Create a case-insensitive, ordered regex pattern
        const regexPattern = words.join(".*"); // e.g. "bike red" => /bike.*red/
        const regex = new RegExp(regexPattern, "i");

        const results = await Rental.find({
            title: { $regex: regex },
        });

        res.status(200).json(results);
    } catch (err) {
        console.error("Search error:", err);
        res.status(500).json({ message: "Server error during search." });
    }
};

const filterRentals = async (req, res) => {
    try {
        const { category, maxPrice } = req.query;

        const query = {};
        
        if (category) {
            const categoriesArray = Array.isArray(category)
                ? category
                : category.split(',');
            query.category = { $in: categoriesArray };
        }

        if (maxPrice) query.price = { $lte: parseFloat(maxPrice) };

        const rentals = await Rental.find(query);
        res.status(200).json(rentals);
    } catch (err) {
        res.status(500).json({ error: "Failed to filter rentals", details: err.message });
    }
};

// Get rentals by type (offers/requests) - currently fetches all rentals
const getRentalsByType = async (req, res) => {
    const { type } = req.params;
    console.log(`Fetching rentals for type: ${type}`); // Debug log

    // Validate type parameter
    if (type !== 'offers' && type !== 'requests') {
        console.log('Invalid type requested:', type);
        return res.status(400).json({ error: 'Invalid type parameter. Use \'offers\' or \'requests\'.' });
    }

    try {
        // Always query the Rental model for this route
        const items = await Rental.find().sort({ createdAt: -1 });

        if (!items || items.length === 0) {
            console.log(`No rentals found (requested type: ${type})`);
            return res.status(200).json([]); // Return 200 OK with an empty array if no rentals exist
        }

        console.log(`Successfully fetched ${items.length} rentals (requested type: ${type})`);
        res.status(200).json(items);
    } catch (err) {
        console.error(`Error fetching rentals (requested type: ${type}):`, err);
        res.status(500).json({ error: `Failed to fetch rentals`, details: err.message });
    }
};

// Get rental requests by type (offers/requests)
const getRentalRequestsByType = async (req, res) => {
    const { type } = req.params;
    console.log(`Fetching rental requests for type: ${type}`); // Debug log

    // Validate type parameter
    if (type !== 'offers' && type !== 'requests') {
        console.log('Invalid type requested for rental requests:', type);
        return res.status(400).json({ error: 'Invalid type parameter. Use \'offers\' or \'requests\'.' });
    }

    // Future Enhancement: If RentalRequest schema gets a 'type' field, 
    // you could filter here: await RentalRequest.find({ type: type }).sort(...)
    try {
        // Always query the RentalRequest model for this function
        const items = await RentalRequest.find().sort({ createdAt: -1 });

        if (!items || items.length === 0) {
            console.log(`No rental requests found (requested type: ${type})`);
            // Return 200 OK with an empty array if no requests exist
            return res.status(200).json([]); 
        }

        console.log(`Successfully fetched ${items.length} rental requests (requested type: ${type})`);
        res.status(200).json(items);
    } catch (err) {
        console.error(`Error fetching rental requests (requested type: ${type}):`, err);
        res.status(500).json({ error: `Failed to fetch rental requests`, details: err.message });
    }
};

module.exports = { 
    uploadNewRental,
    getRentals,
    getUserRentals,
    editRental,
    deleteRental,
    searchRentals,
    filterRentals,
    getRentalsByType,
    getRentalRequestsByType,
};